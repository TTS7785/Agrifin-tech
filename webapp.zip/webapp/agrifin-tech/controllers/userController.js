﻿// @desc Get all users
// @route GET /api/users
// @access public
const getUsers = (req, res) => {
  // @TODO
  res.status(200).json({message:'Get all users.'});
};

// @desc Create all users
// @route POST /api/users
// @access public
const createUser = (req, res) => {
  const {id, name, password, roles, user_type} = req.body;
  // @NOTE: roles and user_type are user defined enumerations
  // @TODO: evaluate enum entries
  if (!name || !password || !roles || !user_type) {
    res.status(400);
    throw new Error('One or more required fields are missing!');
  }
  // @TEMP: return the same data for now to confirm that data was accepted
  // @TODO: add more conditions to make local tests
  res.status(201).json(req.body);
};

// @desc Get user
// @route GET /api/users
// @access public
const getUser = (req, res) => {
  // @TODO
  res.status(200).json({message:`Get user for ${req.params.id}`});
};

// @desc Update user
// @route PUT /api/users
// @access public
const updateUser = (req, res) => {
  // @TODO
  res.status(202).json({message:`Update user for ${req.params.id}`});
};

// @desc Dete user
// @route DELETE /api/users
// @access public
const deleteUser = (req, res) => {
  // TODO
  res.status(203).json({message:`User deleted for ${req.params.id}`});
};

module.exports = { getUsers, createUser, getUser, updateUser, deleteUser };
