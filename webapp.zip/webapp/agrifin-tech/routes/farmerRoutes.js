﻿const express = require('express');
const router = express.Router();
const { getFarmers, createFarmer, getFarmer, updateFarmer, deleteFarmer } = require('../controllers/farmerController');

router.route('/').get(getFarmers);
router.route('/').post(createFarmer);
router.route('/:id').get(getFarmer);
router.route('/:id').put(updateFarmer);
router.route('/:id').delete(deleteFarmer);

module.exports = router;
