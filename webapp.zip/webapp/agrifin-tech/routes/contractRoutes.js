﻿const express = require('express');
const router = express.Router();
const { getContracts, createContract, getContract, updateContract, deleteContract } = require('../controllers/contractController');

router.route('/').get(getContracts);
router.route('/').post(createContract);
router.route('/:id').get(getContract);
router.route('/:id').put(updateContract);
router.route('/:id').delete(deleteContract);

module.exports = router;
