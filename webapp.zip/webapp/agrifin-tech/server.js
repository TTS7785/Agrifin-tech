﻿const express = require('express');
const dotenv = require('dotenv').config();
const errorHandler = require('./middleware/errorHandler');
const userRoutes = require('./routes/userRoutes');
const farmerRoutes = require('./routes/farmerRoutes');
const contractRoutes = require('./routes/contractRoutes');

const app = express();

app.use(express.json());
app.use('/api/users', userRoutes);
app.use('/api/farmers', farmerRoutes);
app.use('/api/contract', contractRoutes);
app.use(errorHandler);

const port = process.env.SVR_PORT || 5000;

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
