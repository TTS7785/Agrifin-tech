-- Create the Turmi database
CREATE DATABASE turmi_db
  WITH
    ENCODING = 'UTF8'
    LC_COLLATE = 'und-x-icu'
    LC_CTYPE   = 'und-x-icu'
    TEMPLATE = template0